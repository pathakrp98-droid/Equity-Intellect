#!/usr/bin/env bash
set -euo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="${1:-$PWD}"

if [[ ! -f "$TARGET_DIR/package.json" ]]; then
  echo "Error: target does not appear to be the repository root: $TARGET_DIR" >&2
  exit 1
fi

for path in lib artifacts docs scripts README_ALPHA_DESK_V0.8.md; do
  if [[ -e "$SOURCE_DIR/$path" ]]; then
    cp -R "$SOURCE_DIR/$path" "$TARGET_DIR/"
  fi
done

chmod +x "$TARGET_DIR/scripts/phase8-smoke.mjs" 2>/dev/null || true

echo "AlphaDesk v0.8 cumulative files applied to $TARGET_DIR"
echo "Next: run database push, typecheck, build and the Phase 8 acceptance checklist."
